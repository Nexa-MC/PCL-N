# NexaCL 本轮改动验证

- 本轮范围：亮暗图标、Splash、主窗口入场与关闭、资源连续列表及详情、外观设置移除低功耗。
- 素材：30 张实际 X11 PNG、10 段包含真实变化帧的单次播放 GIF。
- 所有资源记录、失败和重试响应为明确标注的受控演示资料。
- 设置 native 截图全为 1040×740，保留帧率、减少动态和完整外观页底部。
- gallery-validation.json：Chromium 的实际主题/分类/重播/下载/缩放检查；exact HTML 经 set_content 加载，不更改托管浏览器的 file URL 策略。
- Release：Desktop 252/252、Avalonia Backend 28/28、Services 713/713、UI.Next 105、PXML 40、Architecture 70 projects。
- 最终 NativeAOT Desktop 测试：252/252，独立原生资源滚动及同页重试通过。
- 最终 NativeAOT 与 full-link trim 发布：无 compiler/linker 警告/错误，shell/setup 验证通过。
- 实际 NativeAOT 启动器：单进程转交、nexacl 协议注册、首次设置、正常关闭通过。
- 置顶/焦点为 managerless Xvfb 原生请求和采样证据；不代替其他平台的物理合成器验证。

原始帧、录像、fixture 用户目录、日志和失败探索不包含在交付 ZIP 中。
