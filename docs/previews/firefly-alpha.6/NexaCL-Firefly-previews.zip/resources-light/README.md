# Resource page previews

Actual native-window screenshots and continuous-list GIF. The GIF plays once; replay is provided by the aggregate preview index. All resource records and provider failures are controlled typed fixture data; these artifacts do not prove live provider/network behavior. Wheel/click events use the actual routed Backend path, not physical-device/XTest input.

[light continuous list GIF](resource-continuous-light.gif)

- [list-initial](list-initial-light.png)
- [append-loading](append-loading-light.png)
- [appended](appended-light.png)
- [next-loading](next-loading-light.png)
- [failed](failed-light.png)
- [retry-loading](retry-loading-light.png)
- [retry-success](retry-success-light.png)
- [detail](detail-light.png)
- [back](back-light.png)
