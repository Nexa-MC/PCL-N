# NexaCL 本轮实际界面预览

打开 index.html 可离线浏览、切换主题、重播有限 GIF、下载单项图片。
范围：Splash、主窗口、资源连续列表与详情、外观设置。资源记录和失败响应为受控演示数据；设置使用临时本地文件。
全部图片来自实际 X11 原生 UI；GIF 来自真实采样，只有一次播放，不以静态图伪造。
Xvfb/software/private DBus/no-WM 的前提见各目录 metadata 和验证说明。
previews.zip 只包含 allowlist 的本轮实际图片、离线 HTML、素材清单和采集说明；不包含 fixtures、原始帧、录像、日志或探索失败目录。
