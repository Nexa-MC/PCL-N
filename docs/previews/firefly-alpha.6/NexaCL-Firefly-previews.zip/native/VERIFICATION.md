# 本轮原生预览验证

本目录来自最终新版 managed Desktop，已移除 LowPower 并包含 explicit ReducedMotion 启动投影/首次显示修正。
来源程序及 Desktop/backend/UI assembly SHA-256、UTC 采样时刻记在 manifest.json。

```sh
source /workspace/.pcln-cloud/env.sh
dbus-run-session -- /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python eng/previews/capture_neon_previews.py --binary /workspace/PCL-N/Nexa.Desktop/bin/Release/net10.0/Nexa.Desktop --display :98 --fps 60 --output /workspace/.pcln-cloud/neon-previews/native
```

实际 X11 root 像素由 PID-qualified 原生窗口矩形裁剪，保存每个源 PNG 帧及真实单调时钟采样时间。
首次显示前已观察到 hidden prepared XID；5ms 检查 mapping 后开始采样。两次正常 native close 均退出 0。
Light 的 N 轨迹可见于 7 个采样帧、5 个不同轨迹状态；Dark 为 5 帧、3 个不同状态。
两种 Splash 的180ms入场均有至少3个不同 header 像素状态，因此没有使用loading-stage fallback。
主窗原 PNG 为850×500，Splash为400×280；主窗GIF缩至640×376，Splash保持400×280。
每个 GIF 不包含无限 loop 扩展，只播放一次。时长包括真实采样到的入场前/后的短暂静止区间。

| Theme | 动画 | 源帧 / GIF帧 | 字节 | 采样时长 |
| --- | --- | --- | --- | --- |
| light | splash | 23 / 17 | 42,019 | 611.8 ms |
| light | entrance | 29 / 24 | 86,694 | 878.3 ms |
| light | close | 26 / 21 | 85,945 | 771.6 ms |
| dark | splash | 17 / 17 | 34,230 | 583.3 ms |
| dark | entrance | 28 / 24 | 98,312 | 862.9 ms |
| dark | close | 21 / 20 | 75,926 | 711.4 ms |

前提：专用 Xvfb :98 无窗口管理器，显式使用既有 software-rendering 设置；动画未禁用。
Main 映射后请求真实 core X11 焦点以模拟普通 WM 的前台主窗，Splash保留passive显示。
私有DBus session不具有真实tray host，所以isolated fixture设置 UiTrayEnabled=false。
无WM环境的真实像素与focus可以验证，物理 compositor 置顶/桌面WM激活行为仍需平台验证。

之前未计为最终的探索数据保存在同级 native-first-failed、native-v2、native-v3 和
native-before-startup-pref-fix；聚合预览仅应链接本目录。
