# Resource page previews

Actual native-window screenshots and continuous-list GIF. The GIF plays once; replay is provided by the aggregate preview index. All resource records and provider failures are controlled typed fixture data; these artifacts do not prove live provider/network behavior. Wheel/click events use the actual routed Backend path, not physical-device/XTest input.

[dark continuous list GIF](resource-continuous-dark.gif)

- [list-initial](list-initial-dark.png)
- [append-loading](append-loading-dark.png)
- [appended](appended-dark.png)
- [next-loading](next-loading-dark.png)
- [failed](failed-dark.png)
- [retry-loading](retry-loading-dark.png)
- [retry-success](retry-success-dark.png)
- [detail](detail-dark.png)
- [back](back-dark.png)
